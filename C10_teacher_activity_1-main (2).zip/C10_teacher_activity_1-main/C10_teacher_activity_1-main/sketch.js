var marks=[80,99,89,86,30]
console.log(marks[2])

function average_marks(){
  var summarks=marks[0]+marks[1]+marks[2]+marks[3]+marks[4]
  var average_marks=summarks/marks.length
  console.log(average_marks)

}


function setup() {
  createCanvas(400, 400);
  average_marks()
}

function draw() {
  background(220);
}